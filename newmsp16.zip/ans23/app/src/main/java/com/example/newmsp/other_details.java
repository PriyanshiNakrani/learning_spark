package com.example.newmsp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.google.android.material.button.MaterialButton;

import java.util.*;
import android.app.DatePickerDialog;

public class other_details extends AppCompatActivity {

    MaterialButton btncontinue;
    EditText dateET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_details);

        btncontinue = findViewById(R.id.btncontinue);
        dateET=findViewById(R.id.dateET);

        btncontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(other_details.this, Student_home.class);
                startActivity(i);
            }
        });
        dateET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               selectDate();
            }
        });
    }

    private void selectDate() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                dateET.setText(day + "-" + (month + 1) + "-" + year);
            }
        }, year, month, day);
        datePickerDialog.show();
    }
}