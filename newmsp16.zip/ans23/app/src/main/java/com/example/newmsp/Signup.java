package com.example.newmsp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.newmsp.utils.PrefUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Signup extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        Button btnsignup = findViewById(R.id.btnsignup);
        final EditText nameET = findViewById(R.id.nameET);
        final EditText emailET = findViewById(R.id.emailET);
        final EditText passET = findViewById(R.id.passET);
        final EditText phoneET = findViewById(R.id.phoneET);
        final EditText addET = findViewById(R.id.addET);
        final  EditText dateET = findViewById(R.id.dateET);


        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = nameET.getText().toString();
                String email = emailET.getText().toString();
                String password = passET.getText().toString();
                String phoneNo = phoneET.getText().toString();
                String address = addET.getText().toString();
                String date = dateET.getText().toString();

                if ((name.isEmpty() && email.isEmpty() && passET.getText().toString().isEmpty() && phoneET.getText().toString().isEmpty() && addET.getText().toString().isEmpty()) && dateET.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter All Field", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (nameET.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "PLEASE ENTER YOUR NAME", Toast.LENGTH_SHORT).show();
                    return;
                } else if (emailET.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "PLEASE ENTER YOUR EMAIL ID", Toast.LENGTH_SHORT).show();
                    return;
                } else if (passET.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "PLEASE ENTER YOUR PASSWORD", Toast.LENGTH_SHORT).show();
                    return;
                } else if (phoneET.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "PLEASE ENTER YOUR PHONE NUMBER", Toast.LENGTH_SHORT).show();
                    return;
                }else if (addET.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"PLEASE ENTER ADDRESS",Toast.LENGTH_SHORT).show();
                    return;
                }else if (dateET.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Please enter date of joining",Toast.LENGTH_SHORT);
                    return;
                }


                FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

                if (!(name.isEmpty()
                        && email.isEmpty()
                        && password.isEmpty()
                        && phoneNo.isEmpty()
                        && address.isEmpty()
                        && date.isEmpty())
                ) {
                    firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {
                                String aid = task.getResult().getUser().getUid();
/*                                SharedPreferences preferences = getSharedPreferences(Constant.PREFERENCE_NAME, MODE_PRIVATE);
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString(Constant.PREF_AID, aid);
                                editor.commit();*/
                                MyApp.setStringPrefs(Constant.PREF_AID, aid);


                                Admin a = new Admin();
                                a.setAid(aid);
                                a.setName(name);
                                a.setEmail(email);
                                a.setPassword(password);
                                a.setPhoneNumber(phoneNo);
                                a.setLogintype(0);
                                a.setAddress(address);
                                a.setDate(date);


                                //TODO:check-it

                                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).setValue(a);

                                Toast.makeText(getApplicationContext(), "registration successfull !! Try to log in", Toast.LENGTH_LONG).show();

                                Intent i = new Intent(Signup.this, MainActivity.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(getApplicationContext(), task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
            }
        });

    }
}