package com.example.newmsp;

public class Constant {

    //Shared_preference
    public static final String PREFERENCE_NAME = "MyPref";
    public static final String PREF_LOGIN = "isLogin";
    public static final String PREF_LOGIN_TYPE = "LoginType";
    public static final String PREF_AID = "user_aid";

    //RealTime-DataBase
    public static final String DATABASE_ROOT = "users";
    public static final String DB_MEDIUM = "medium";
    public static final String DB_STD = "standard";
    public static final String DB_JOINING_DATE = "join_date";
    public static final String DB_ADDRESS = "address";


    //TEMP Variable
    public static String LOGIN_USER_AID = "";


    //Extra-Variable-Name
    public static final String TEACHER = "Teacher";
    public static final String STUDENT = "Student";


}
