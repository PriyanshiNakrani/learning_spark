package com.example.newmsp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class s_std_e extends AppCompatActivity {

    MaterialCardView carde1,carde2,carde3,carde4,carde5,carde6,carde7,carde8,carde9,carde10;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();


    DatabaseReference userRef = FirebaseDatabase.getInstance().getReference(Constant.DATABASE_ROOT);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_std_e);

        carde1 = findViewById(R.id.carde1);
        carde2 = findViewById(R.id.carde2);
        carde3 = findViewById(R.id.carde3);
        carde4 = findViewById(R.id.carde4);
        carde5 = findViewById(R.id.carde5);
        carde6 = findViewById(R.id.carde6);
        carde7 = findViewById(R.id.carde7);
        carde8 = findViewById(R.id.carde8);
        carde9 = findViewById(R.id.carde9);
        carde10 = findViewById(R.id.carde10);

        carde1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i = new Intent(s_std_e.this,admin_upload_file.class);
                startActivity(i); */

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("1").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        carde2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/


                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("2").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        carde3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("3").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        carde4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("4").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        carde5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("5").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

        carde6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("6").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });




            }
        });

        carde7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("7").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        carde8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("8").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });



            }
        });

        carde9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/

                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("9").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });



            }
        });

        carde10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Intent i = new Intent(s_std_e.this,other_details.class);
                startActivity(i);*/
                String aid = MyApp.getStringPrefs(Constant.PREF_AID);
                Log.e("TAG---", "onClick: LOGIN_USER_AID :  "+ aid );
                firebaseDatabase.getReference().child(Constant.DATABASE_ROOT).child(aid).child(Constant.DB_STD).setValue("10").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        startActivity(new Intent(s_std_e.this, Student_home.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(s_std_e.this, "Something went wrong...!" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

    }
}