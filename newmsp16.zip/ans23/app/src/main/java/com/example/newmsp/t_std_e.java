package com.example.newmsp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class t_std_e extends AppCompatActivity {

    MaterialCardView carde1,carde2,carde3,carde4,carde5,carde6,carde7,carde8,carde9,carde10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_std_e);

        carde1 = findViewById(R.id.carde1);
        carde2 = findViewById(R.id.carde2);
        carde3 = findViewById(R.id.carde3);
        carde4 = findViewById(R.id.carde4);
        carde5 = findViewById(R.id.carde5);
        carde6 = findViewById(R.id.carde6);
        carde7 = findViewById(R.id.carde7);
        carde8 = findViewById(R.id.carde8);
        carde9 = findViewById(R.id.carde9);
        carde10 = findViewById(R.id.carde10);

        carde1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,admin_upload_file.class);
                startActivity(i);
            }
        });

        carde2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

        carde10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_e.this,other_details.class);
                startActivity(i);
            }
        });

    }
}