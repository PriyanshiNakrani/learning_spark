package com.example.newmsp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Student_Profile extends AppCompatActivity {

    Button editProifle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);


        editProifle=(Button) findViewById(R.id.editProfile);

        editProifle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), s_medium.class);
                startActivity(i);
            }
        });

    }
}