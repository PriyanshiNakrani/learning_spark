package com.example.newmsp;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class PracticeAdapter extends FragmentPagerAdapter {

    private Context context;
    int totalTabs;

    public PracticeAdapter (FragmentManager fm, Context context, int totalTabs){

        super(fm);
        this.context = context;
        this.totalTabs = totalTabs;
    }

    @Override
    public int getCount() {
        return totalTabs;
    }

    public Fragment getItem(int position){

        switch (position){
            case 0:
                assignment_fragment assignment_fragment = new assignment_fragment();
                return assignment_fragment;

            case 1:
                test_fragment test_fragment = new test_fragment();
                return test_fragment;

            case 2:
                notes_fragment notes_fragment = new notes_fragment();
                return notes_fragment;

            default:
                return null;
        }
    }
}
