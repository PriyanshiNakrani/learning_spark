package com.example.newmsp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class Student_home extends AppCompatActivity {

    BottomNavigationView nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_home);

        nav = findViewById(R.id.nav);

        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                ImageSlider imageSlider = findViewById(R.id.imageSlider);
                ArrayList<SlideModel> slideModels = new ArrayList<>();

                slideModels.add(new SlideModel(R.drawable.image1, ScaleTypes.FIT));
                slideModels.add(new SlideModel(R.drawable.image2, ScaleTypes.FIT));
                slideModels.add(new SlideModel(R.drawable.image3, ScaleTypes.FIT));
                slideModels.add(new SlideModel(R.drawable.image4, ScaleTypes.FIT));

                imageSlider.setImageList(slideModels, ScaleTypes.FIT);

                switch (item.getItemId()){

                    case R.id.home:
                        Toast.makeText(Student_home.this, "HOME", Toast.LENGTH_SHORT).show();
                        break;


                    case R.id.practice:
                        Intent i = new Intent(getApplicationContext(), Student_practice.class);
                        startActivity(i);


                    case R.id.chat:
                        Toast.makeText(Student_home.this, "CHAT", Toast.LENGTH_SHORT).show();
                        break;


                    case R.id.profile:

                        Intent in = new Intent(getApplicationContext(), Student_Profile.class);
                        startActivity(in);

                        //Toast.makeText(Student_home.this, "PROFILE", Toast.LENGTH_SHORT).show();
                        break;


                    default:
                }

                return true;
            }
        });

    }
}