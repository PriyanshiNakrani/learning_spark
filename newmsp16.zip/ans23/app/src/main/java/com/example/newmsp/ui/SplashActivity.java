package com.example.newmsp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.example.newmsp.Constant;
import com.example.newmsp.MainActivity;
import com.example.newmsp.MyApp;
import com.example.newmsp.R;
import com.example.newmsp.Student_home;
import com.example.newmsp.admin2home;
import com.example.newmsp.utils.PrefUtil;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (MyApp.getBooleanPrefs(Constant.PREF_LOGIN)) {

                    if (MyApp.getStringPrefs(Constant.PREF_LOGIN_TYPE).equals(Constant.STUDENT)) {
                        startActivity(new Intent(SplashActivity.this, Student_home.class));
                    }
                    else if (MyApp.getStringPrefs(Constant.PREF_LOGIN_TYPE).equals(Constant.TEACHER)) {
                        startActivity(new Intent(SplashActivity.this, admin2home.class));
                    }
                    else {
                        Toast.makeText(SplashActivity.this, "No User Type", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                }

            }
        }, 3000);
    }
}