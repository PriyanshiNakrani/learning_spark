package com.example.newmsp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class t_std_g extends AppCompatActivity {

    MaterialCardView cardg1,cardg2,cardg3,cardg4,cardg5,cardg6,cardg7,cardg8,cardg9,cardg10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_std_g);

        cardg1 = findViewById(R.id.cardg1);
        cardg2 = findViewById(R.id.cardg2);
        cardg3 = findViewById(R.id.cardg3);
        cardg4 = findViewById(R.id.cardg4);
        cardg5 = findViewById(R.id.cardg5);
        cardg6 = findViewById(R.id.cardg6);
        cardg7 = findViewById(R.id.cardg7);
        cardg8 = findViewById(R.id.cardg8);
        cardg9 = findViewById(R.id.cardg9);
        cardg10 = findViewById(R.id.cardg10);

        cardg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });

        cardg10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(t_std_g.this,other_details.class);
                startActivity(i);
            }
        });
    }
}